import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Digite os números (digite 0 para encerrar):");

    int soma = 0;
    int numero;

    do {
        numero = scanner.nextInt();
        soma += numero;
    } while (numero != 0);

    System.out.println("O somatório é: " + soma);

    scanner.close();
  }
}
