import java.util.Scanner;

public class Main {

    public static boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Insira um numero: ");
        int number = input.nextInt();

          input.close();

        if (isPrime(number)) {
            System.out.println(number + " é primo.");
        } else {
            System.out.println(number + " nao é primo.");
        }
    }
}
