import java.util.Scanner;

public class Main {

  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Digite o numero de numeros:");
    int n = input.nextInt();

    System.out.println("Digite o numero:");
    int firstValue = input.nextInt();
    int largestValue = firstValue;
    int smallestValue = firstValue;

    for (int i = 1; i < n; i++) {
      System.out.println("Digite o numero:");
      int value = input.nextInt();
      if (value > largestValue) {
        largestValue = value;
      }
      if (value < smallestValue) {
        smallestValue = value;
      }
    }
    input.close();

    int count = 0;
    for (int i = smallestValue; i <= largestValue; i++) {
      count++;
    }

    System.out.println("Entre " + smallestValue + " e " + largestValue + " existem " + count + " numeros");
  }
}
